# -*- coding: utf-8 -*-
"""
Created on Sat Oct 15 15:13:29 2022

@author: jlusk
"""

import scipy.cluster.hierarchy as sch
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.impute import SimpleImputer
from sklearn.impute import KNNImputer
from sklearn.neighbors import LocalOutlierFactor
from sklearn.preprocessing import StandardScaler

dfTest = pd.read_csv("Phishing_Legitimate_test_student.csv", na_values=['',' ','n/a'])
dfTrain = pd.read_csv("Phishing_Legitimate_train_missing_data.csv", na_values=['',' ','n/a'])
################## Getting all the missing/NA values##################################################################
print(dfTrain.isnull().sum())
print(dfTrain.isnull().any(axis=0))
print(dfTrain.isnull().any(axis=1))
trainRowsWithNa = dfTrain[ dfTrain.isnull().any(axis=1) ]

################### Test has no missing/Na values  ##########################################################
print(dfTest.isnull().sum())
print(dfTest.isnull().any(axis=0))
print(dfTest.isnull().any(axis=1))

################### kNN to replace NA values ####################
# book says KNN is the best method to use #
rowsToDrop = dfTrain[ dfTrain.isnull().sum(axis=1) > 1 ].index
#dfTrain.drop(rowsToDrop, inplace=True) /drops NA rows
imputer = KNNImputer(n_neighbors=10)
# i just made a new dataframe instead of transforming the other
dfTrain2 = pd.DataFrame(imputer.fit_transform(dfTrain),columns = dfTrain.columns)

####### KNNing testing data 
dfTest2 = pd.DataFrame(imputer.fit_transform(dfTest),columns = dfTest.columns)

############# outlier identification ###################
plt.figure()
#FrequentDomainNameMismatch is not in the list for some reason
df7Attr = dfTrain2[['UrlLength','EmbeddedBrandName','ExtFavicon','PopUpWindow','NoHttps','InsecureForms']]
df7Attr.plot.box()
plt.show()

####### finding outliers #######
clf = LocalOutlierFactor(n_neighbors=20)
X = df7Attr.to_numpy()
outlier_label = clf.fit_predict(X)

print(clf.negative_outlier_factor_)
print(clf.offset_)
print(outlier_label)
plt.boxplot(clf.negative_outlier_factor_)
#### rows to drop using LOF ####
LOFrows_to_drop= df7Attr.iloc[ clf.negative_outlier_factor_ < -1.5].index
LOFdfTrain = df7Attr.drop(LOFrows_to_drop,inplace=True)
### LOF_kNN_dfTrain 
LOF_kNN_dfTrain = df7Attr.drop(LOFrows_to_drop,inplace=True)

list_of_col_names = list(dfTrain2.columns)

########### Standardization ########################

dfTrain2Numerical = dfTrain2[['NumNumericChars','NumDots','SubdomainLevel','PathLevel','NumDash','NumDashInHostname',
          'NumUnderscore','NumPercent','NumQueryComponents','NumAmpersand','NumHash','HostnameLength','PathLength','QueryLength','NumSensitiveWords']]
X = dfTrain2Numerical.to_numpy()
scaler = StandardScaler()
scaler.fit(X)
X = scaler.transform(X)
dfTrain2Numerical[['NumNumericChars_Standardized','NumDots_Standardized','SubdomainLevel_Standardized','PathLevel_Standardized','NumDash_Standardized','NumDashInHostname_Standardized',
          'NumUnderscore_Standardized','NumPercent_Standardized','NumQueryComponents_Standardized','NumAmpersand_Standardized','NumHash_Standardized','HostnameLength_Standardized','PathLength_Standardized','QueryLength_Standardized','NumSensitiveWords_Standardized']]=X
sns.boxplot(data=dfTrain2Numerical[['NumNumericChars','NumDots','SubdomainLevel','PathLevel','NumDash','NumDashInHostname',
          'NumUnderscore','NumPercent','NumQueryComponents','NumAmpersand','NumHash','HostnameLength','PathLength','QueryLength','NumSensitiveWords']])
sns.boxplot(data=dfTrain2Numerical[['NumNumericChars_Standardized','NumDots_Standardized','SubdomainLevel_Standardized','PathLevel_Standardized','NumDash_Standardized','NumDashInHostname_Standardized',
          'NumUnderscore_Standardized','NumPercent_Standardized','NumQueryComponents_Standardized','NumAmpersand_Standardized','NumHash_Standardized','HostnameLength_Standardized','PathLength_Standardized','QueryLength_Standardized','NumSensitiveWords_Standardized']])

############ Catagorical #########################################
dfTrainCategorical = dfTrain2[['AbnormalFormAction','UrlLengthRT','PctExtResourceUrlIsRT','AbnormalExtFormActionR','ExtMetaScriptLinkRT','PctExtNullSelfRedirectHyperlinksRT']]

